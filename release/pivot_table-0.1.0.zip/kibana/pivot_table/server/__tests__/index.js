import { expect } from 'chai';

describe('suite', () => {
  it('is a test test', () => {
    expect(true).to.equal(false);
  });
});
